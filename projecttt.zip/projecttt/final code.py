from tkinter import messagebox
from tkinter import *
from tkinter.filedialog import askopenfilename
from tkinter import simpledialog
import tkinter
import numpy as np
from tkinter import filedialog
from sklearn.model_selection import train_test_split 
import matplotlib.pyplot as plt
from scapy.all import *
from multiprocessing import Queue
#from SignatureBasedDetection import *#
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import precision_score,f1_score,recall_score,accuracy_score 
import webbrowser
import csv

main = tkinter.Tk()
main.title("Two Factor Worm Detection Based on Signature & Anomaly")
main.geometry("1300x1200")


global filename
accuracy = []
global dataset
global X, Y
global X_train, X_test, y_train, y_test
global output
global classifier
global le
global y_train_encoded, y_test_encoded 

# Define worm signatures
worm_signatures = {
    "code_red1": {"Number of announcements": 900, "Number of withdrawals": 500, 
                  "Number of announced NLRI prefixes": 200, "Number of withdrawn NLRI prefixes": 100},
    "slammer": {"Number of announcements": 500, "Number of withdrawals": 200, 
                "Number of announced NLRI prefixes": 100, "Number of withdrawn NLRI prefixes": 50},
    "nimda": {"Number of announcements": 800, "Number of withdrawals": 300, 
              "Number of announced NLRI prefixes": 150, "Number of withdrawn NLRI prefixes": 80},
    "witty": {"Number of announcements": 600, "Number of withdrawals": 250, 
              "Number of announced NLRI prefixes": 120, "Number of withdrawn NLRI prefixes": 60}
}

def runSignatureDetection():
    global dataset
    text.delete('1.0', END)
    text.insert(END, "Running Signature Based Detection...\n")
    
    # Load dataset
    dataset = pd.read_csv("C:\\Users\\AKSHARA\\Desktop\\Project\\Book11.csv")
    
    # Check for each signature
    for worm, signature in worm_signatures.items():
        anomalies = analyze_data(signature)
        if anomalies:
            text.insert(END, f"Worm detected for {worm}: {', '.join(anomalies)}\n"+"\n")
def analyze_data(signature):
    detected_anomalies = []
    for feature, threshold in signature.items():
        if dataset[feature].mean() > threshold:
            detected_anomalies.append(f"Anomaly detected in feature {feature}!")
    return detected_anomalies



def uploadAnomaly():
    global le
    text.delete('1.0', END)
    global dataset
    global X, Y
    global X_train, X_test, y_train, y_test
    global filename
    filename = filedialog.askopenfilename(initialdir="Book11.Book11.csv")
    text.delete('1.0', END)
    text.insert(END, 'IDS dataset loaded\n')

    if filename.endswith('.xls') or filename.endswith('.xlsx'):
        dataset = pd.read_excel(filename)
    else:
        dataset = pd.read_csv(filename)

    temp = dataset.copy()
    le = LabelEncoder()
    dataset['attack_cat'] = pd.Series(le.fit_transform(dataset['attack_cat']))
    dataset['Number of incomplete packets'] = pd.Series(le.fit_transform(dataset['Number of incomplete packets']))
    dataset['Average AS-path length'] = pd.Series(le.fit_transform(dataset['Average AS-path length']))
    dataset['Label'] = pd.Series(le.fit_transform(dataset['Label']))

    temp = temp.values
    worm = temp[:, temp.shape[1] - 1]
    (worm, count) = np.unique(worm, return_counts=True)
    dataset = dataset.values
    X = dataset[:, 0:dataset.shape[1] - 1]
    Y = dataset[:, dataset.shape[1] - 1]
    print(Y)

    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2)
    text.insert(END, "Dataset contains total records : " + str(len(X)) + "\n")
    text.insert(END, "Train & Test Dataset Splits to 80 and 20%\n")
    text.insert(END, "Dataset records to train classification model : " + str(len(X_train)) + "\n")
    text.insert(END, "Dataset records to test classification model : " + str(len(X_test)) + "\n")

    fig, ax = plt.subplots()
    y_pos = np.arange(len(worm))
    plt.bar(y_pos, count)
    plt.xticks(y_pos, worm)
    ax.xaxis_date()
    fig.autofmt_xdate()
    plt.show()

def runAnomalyDetection():
    global classifier
    global X_train, X_test, y_train, y_test
    text.delete('1.0', END)
    global output
    output = ''
    output='<html><body><center><table border=1><tr><th>Algorithm Name</th><th>Accuracy</th><th>Precision</th><th>Recall</th><th>FScore</th></tr>'
    accuracy.clear()
    
    # Initialize LabelEncoder
    le = LabelEncoder()
    # Fit LabelEncoder on the combined target variable
    y_train_series = pd.Series(y_train)
    y_test_series = pd.Series(y_test)
    y_combined = pd.concat([y_train_series, y_test_series])

    le.fit(y_combined)
    
    # Transform both y_train and y_test using the same LabelEncoder
    y_train_encoded = le.transform(y_train)
    y_test_encoded = le.transform(y_test)

    
    dt = DecisionTreeClassifier(max_depth=70)
    dt.fit(X_train, y_train_encoded)
    predict = dt.predict(X_test) 
    tree_acc = accuracy_score(y_test_encoded, predict) * 100
    text.insert(END, "Decision Tree Classification Algorithm Prediction Accuracy: " + str(tree_acc) + "\n")
    accuracy.append(tree_acc)
    precision = precision_score(y_test_encoded, predict, zero_division=1, average='macro') * 100
    recall = recall_score(y_test_encoded, predict, average='macro') * 100
    fmeasure = f1_score(y_test_encoded, predict, average='macro') * 100
    output += '<tr><td>Decision Tree</td><td>' + str(tree_acc) + '</td><td>' + str(precision) + '</td><td>' + str(recall) + '</td><td>' + str(fmeasure) + '</td></tr>'

    rf = RandomForestClassifier(n_estimators=90, random_state=42)
    rf.fit(X_train, y_train_encoded)
    predict = rf.predict(X_test) 
    rf_acc = accuracy_score(y_test_encoded, predict) * 100
    classifier = rf
    text.insert(END, "Random Forest Classification Algorithm Prediction Accuracy: " + str(rf_acc) + "\n")
    accuracy.append(rf_acc)
    precision = precision_score(y_test_encoded, predict, average='macro') * 100
    recall = recall_score(y_test_encoded, predict, average='macro') * 100
    fmeasure = f1_score(y_test_encoded, predict, average='macro') * 100
    output += '<tr><td>Random Forest</td><td>' + str(rf_acc) + '</td><td>' + str(precision) + '</td><td>' + str(recall) + '</td><td>' + str(fmeasure) + '</td></tr>'
    

def graph():    
    height = accuracy
    bars = ('Decision Tree Accuracy', 'Random Forest Accuracy')
    y_pos = np.arange(len(bars))
    plt.bar(y_pos, height)
    plt.xticks(y_pos, bars)
    plt.show()

def compareTable():
    global output
    f = open("table.html", "w")
    f.write(output)
    f.close()
    webbrowser.open("table.html",new=2)
    
def close():
    main.destroy()

font = ('times', 16, 'bold')
title = Label(main, text='Two Factor Worm Detection Based on Signature & Anomaly')
title.config(bg='chocolate', fg='white')  
title.config(font=font)           
title.config(height=3, width=120)       
title.place(x=0,y=5)

font1 = ('times', 13, 'bold')

predictButton = Button(main, text="Run Signature Based Worm Detection", command=runSignatureDetection)
predictButton.place(x=700,y=200)
predictButton.config(font=font1)

svmButton = Button(main, text="Upload Anomaly Dataset", command=uploadAnomaly)
svmButton.place(x=700,y=250)
svmButton.config(font=font1) 

knnButton = Button(main, text="Run Machine Learning Based Anomaly Detection", command=runAnomalyDetection)
knnButton.place(x=700,y=300)
knnButton.config(font=font1)

batButton = Button(main, text="Comparison Graph", command=graph)
batButton.place(x=700,y=350)
batButton.config(font=font1)

batButton = Button(main, text="Comparison Table", command=compareTable)
batButton.place(x=700,y=400)
batButton.config(font=font1)

font1 = ('times', 12, 'bold')
text=Text(main,height=30,width=80)
scroll=Scrollbar(text)
text.configure(yscrollcommand=scroll.set)
text.place(x=10,y=100)
text.config(font=font1)

main.config(bg='light salmon')
main.mainloop()

